AletheiaGate v0.7.2 — Polished one-page (CLI consistency + prev_hash naming)
Included:
- AletheiaGate_v0.7.2_One_Page_POLISHED.pdf
- AletheiaGate_v0.7.2_One_Page.pdf (if present)
